// 用 GitHub REST Git Data API 推送（绕开会超时的 git-receive-pack）
// blob -> tree(base_tree) -> commit -> ref
import { Script } from "scripting";
import fs from "node:fs";

declare const fetch: any;

const OWNER = "ckldy";

type FileSpec = { localPath: string; repoPath: string };

type RepoSpec = {
  repo: string;
  message: string;
  files: FileSpec[];
  tag?: string;
  tagMessage?: string;
};

const LOAD = "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-repos/hanshuang-load-tool";
const PUSH = "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-repos/scripting-scripts-push";
const SRC_DIR = "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripts/寒霜注入工具 2";

const f = (local: string, repoPath: string): FileSpec => ({ localPath: local, repoPath });

const REPOS: RepoSpec[] = [
  {
    repo: "hanshuang-load-tool",
    message: "fix: 工具标记分隔符容错单源化，修复变体泄漏；5190 SSE 工具分支补发正文；升版至 v1.2.5",
    files: [
      f(`${SRC_DIR}/server.ts`, "server.ts"),
      f(`${SRC_DIR}/script.json`, "script.json"),
      f(`${SRC_DIR}/tests/test_tool_tag_variants.ts`, "tests/test_tool_tag_variants.ts"),
      f(`${SRC_DIR}/tests/live_gateway_leak_check.py`, "tests/live_gateway_leak_check.py"),
      f(`${SRC_DIR}/tests/restart_and_verify.py`, "tests/restart_and_verify.py"),
      f(`${SRC_DIR}/tests/restart_and_verify.ts`, "tests/restart_and_verify.ts"),
    ],
    tag: "v1.2.5",
    tagMessage: "v1.2.5: 工具标记分隔符容错 + 5190 SSE 正文补发",
  },
  {
    repo: "scripting-scripts",
    message: "feat: 新增寒霜注入工具 2 (v1.2.5) - 工具标记分隔符容错与 5190 SSE 正文补发",
    files: [
      f(`${PUSH}/寒霜注入工具 2/server.ts`, "寒霜注入工具 2/server.ts"),
      f(`${PUSH}/寒霜注入工具 2/script.json`, "寒霜注入工具 2/script.json"),
      f(`${PUSH}/寒霜注入工具 2/tests/test_tool_tag_variants.ts`, "寒霜注入工具 2/tests/test_tool_tag_variants.ts"),
      f(`${PUSH}/寒霜注入工具 2/tests/live_gateway_leak_check.py`, "寒霜注入工具 2/tests/live_gateway_leak_check.py"),
      f(`${PUSH}/寒霜注入工具 2/tests/restart_and_verify.py`, "寒霜注入工具 2/tests/restart_and_verify.py"),
      f(`${PUSH}/寒霜注入工具 2/tests/restart_and_verify.ts`, "寒霜注入工具 2/tests/restart_and_verify.ts"),
      f(`${PUSH}/README.md`, "README.md"),
      f(`${PUSH}/dist/寒霜注入工具 2.zip`, "dist/寒霜注入工具 2.zip"),
    ],
  },
];

function token(): string {
  const t = String(Keychain.get("isomorphic_git_token") || "");
  if (!t) throw new Error("no token in keychain");
  return t;
}

async function gh(method: string, path: string, body?: any): Promise<any> {
  const res = await fetch(`https://api.github.com${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token()}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
      "User-Agent": "hanshuang-gateway",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let obj: any = null;
  try {
    obj = JSON.parse(text);
  } catch {
    obj = { raw: text.slice(0, 400) };
  }
  if (res.status >= 400) {
    throw new Error(`${method} ${path} -> ${res.status} ${JSON.stringify(obj).slice(0, 400)}`);
  }
  return obj;
}

async function pushRepo(spec: RepoSpec): Promise<any> {
  const base = `/repos/${OWNER}/${spec.repo}`;
  const ref = await gh("GET", `${base}/git/ref/heads/main`);
  const baseCommitSha: string = ref.object.sha;
  const baseCommit = await gh("GET", `${base}/git/commits/${baseCommitSha}`);
  const baseTreeSha: string = baseCommit.tree.sha;

  const tree: any[] = [];
  const uploaded: any[] = [];
  for (const file of spec.files) {
    const buf = fs.readFileSync(file.localPath);
    const blob = await gh("POST", `${base}/git/blobs`, {
      content: buf.toString("base64"),
      encoding: "base64",
    });
    tree.push({ path: file.repoPath, mode: "100644", type: "blob", sha: blob.sha });
    uploaded.push({ path: file.repoPath, bytes: buf.length, sha: blob.sha });
  }

  const newTree = await gh("POST", `${base}/git/trees`, { base_tree: baseTreeSha, tree });
  const commit = await gh("POST", `${base}/git/commits`, {
    message: spec.message,
    tree: newTree.sha,
    parents: [baseCommitSha],
  });
  await gh("PATCH", `${base}/git/refs/heads/main`, { sha: commit.sha, force: false });

  let tagSha: string | null = null;
  if (spec.tag) {
    const tagObj = await gh("POST", `${base}/git/tags`, {
      tag: spec.tag,
      message: spec.tagMessage || spec.tag,
      object: commit.sha,
      type: "commit",
    });
    tagSha = tagObj.sha;
    try {
      await gh("POST", `${base}/git/refs`, { ref: `refs/tags/${spec.tag}`, sha: tagObj.sha });
    } catch (e: any) {
      // 已存在的 tag 不阻断主流程
      tagSha = `${tagSha} (ref: ${String(e?.message || e).slice(0, 80)})`;
    }
  }

  return { repo: spec.repo, baseCommitSha, commitSha: commit.sha, treeSha: newTree.sha, files: uploaded, tagSha };
}

async function main() {
  const results: any[] = [];
  for (const spec of REPOS) {
    try {
      results.push(await pushRepo(spec));
    } catch (e: any) {
      results.push({ repo: spec.repo, error: String(e?.message || e) });
    }
  }
  Script.exit({ results });
}

main();
