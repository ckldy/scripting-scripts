// 验证 Keychain 中的 GitHub token 是否可用于 REST API
import { Script } from "scripting";

declare const fetch: any;

async function main() {
  let token = "";
  try {
    token = String(Keychain.get("isomorphic_git_token") || "");
  } catch (e: any) {
    return Script.exit({ stage: "keychain", error: String(e?.message || e) });
  }
  if (!token) return Script.exit({ stage: "keychain", error: "empty token" });

  try {
    const res = await fetch("https://api.github.com/user", {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
        "User-Agent": "hanshuang-gateway",
      },
    });
    const raw = await res.text();
    let login = null;
    let scopes = res.headers.get("x-oauth-scopes");
    try {
      login = JSON.parse(raw).login ?? null;
    } catch {}
    Script.exit({ status: res.status, login, scopes, tokenLen: token.length, head: raw.slice(0, 200) });
  } catch (e: any) {
    Script.exit({ stage: "fetch", error: String(e?.message || e) });
  }
}

main();
