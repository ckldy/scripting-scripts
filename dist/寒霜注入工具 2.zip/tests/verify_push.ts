// 带 token 核验远端：独立库（私有）与合集库的 commit / 文件内容 / tag
import { Script } from "scripting";

declare const fetch: any;

async function gh(path: string): Promise<any> {
  const token = String(Keychain.get("isomorphic_git_token") || "");
  const res = await fetch(`https://api.github.com${path}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "User-Agent": "hanshuang-gateway",
    },
  });
  const text = await res.text();
  let obj: any = null;
  try {
    obj = JSON.parse(text);
  } catch {
    obj = { raw: text.slice(0, 200) };
  }
  return { status: res.status, obj };
}

async function main() {
  const out: any = {};

  const loadCommit = await gh("/repos/ckldy/hanshuang-load-tool/commits/main");
  out.loadTool = {
    status: loadCommit.status,
    sha: loadCommit.obj?.sha ?? null,
    message: loadCommit.obj?.commit?.message ?? null,
    files: (loadCommit.obj?.files || []).map((f: any) => ({ name: f.filename, status: f.status, add: f.additions })),
  };

  const loadScript = await gh("/repos/ckldy/hanshuang-load-tool/contents/script.json");
  let version = null;
  try {
    const content = String(loadScript.obj.content || "").replace(/\n/g, "");
    const decoded = atob(content);
    version = JSON.parse(decoded).version;
  } catch (e: any) {
    version = `decode-fail: ${String(e?.message || e)}`;
  }
  out.loadToolVersion = { status: loadScript.status, version };

  const tags = await gh("/repos/ckldy/hanshuang-load-tool/tags");
  out.loadToolTags = { status: tags.status, tags: (tags.obj || []).map((t: any) => t.name) };

  const collCommit = await gh("/repos/ckldy/scripting-scripts/commits/main");
  out.collection = {
    status: collCommit.status,
    sha: collCommit.obj?.sha ?? null,
    message: collCommit.obj?.commit?.message ?? null,
    files: (collCommit.obj?.files || []).map((f: any) => ({ name: f.filename, status: f.status })),
  };

  const collScript = await gh("/repos/ckldy/scripting-scripts/contents/寒霜注入工具 2/script.json");
  let collVersion = null;
  try {
    const content = String(collScript.obj.content || "").replace(/\n/g, "");
    collVersion = JSON.parse(atob(content)).version;
  } catch (e: any) {
    collVersion = `decode-fail: ${String(e?.message || e)}`;
  }
  out.collectionVersion = { status: collScript.status, version: collVersion };

  Script.exit(out);
}

main();
