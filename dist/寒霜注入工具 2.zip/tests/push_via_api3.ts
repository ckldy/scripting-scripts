// v1.2.8 推送：5195 全协议（OpenAI 流式/非流式 + Anthropic /v1/messages）+ 5190 缓冲流标记
import { Script } from "scripting";
import fs from "node:fs";

declare const fetch: any;

const OWNER = "ckldy";
const PUSH = "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-repos/scripting-scripts-push";
const SRC = "/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripts/寒霜注入工具 2";

const TEST_FILES = [
  "test_tool_tag_variants.ts",
  "live_gateway_leak_check.py",
  "restart_and_verify.py",
  "restart_and_verify.ts",
  "verify_version.ts",
  "probe_version_source.ts",
  "probe_truncation.ts",
  "probe_ttfb_short.ts",
  "probe_5195_full.ts",
  "probe_anthropic.ts",
  "probe_stall.ts",
];

function token(): string {
  const t = String(Keychain.get("isomorphic_git_token") || "");
  if (!t) throw new Error("no token");
  return t;
}

async function gh(method: string, path: string, body?: any): Promise<any> {
  const res = await fetch(`https://api.github.com${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token()}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
      "User-Agent": "hanshuang-gateway",
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let obj: any = null;
  try {
    obj = JSON.parse(text);
  } catch {
    obj = { raw: text.slice(0, 300) };
  }
  if (res.status >= 400) throw new Error(`${method} ${path} -> ${res.status} ${JSON.stringify(obj).slice(0, 300)}`);
  return obj;
}

async function pushRepo(opts: {
  repo: string;
  message: string;
  files: Array<{ local: string; repoPath: string }>;
  tag?: string;
  tagMessage?: string;
}) {
  const base = `/repos/${OWNER}/${opts.repo}`;
  const ref = await gh("GET", `${base}/git/ref/heads/main`);
  const parent: string = ref.object.sha;
  const parentCommit = await gh("GET", `${base}/git/commits/${parent}`);
  const baseTree: string = parentCommit.tree.sha;

  const tree: any[] = [];
  const uploaded: any[] = [];
  for (const f of opts.files) {
    if (!fs.existsSync(f.local)) {
      uploaded.push({ path: f.repoPath, skipped: "missing-local" });
      continue;
    }
    const buf = fs.readFileSync(f.local);
    const blob = await gh("POST", `${base}/git/blobs`, { content: buf.toString("base64"), encoding: "base64" });
    tree.push({ path: f.repoPath, mode: "100644", type: "blob", sha: blob.sha });
    uploaded.push({ path: f.repoPath, bytes: buf.length, sha: blob.sha });
  }

  const newTree = await gh("POST", `${base}/git/trees`, { base_tree: baseTree, tree });
  const commit = await gh("POST", `${base}/git/commits`, { message: opts.message, tree: newTree.sha, parents: [parent] });
  await gh("PATCH", `${base}/git/refs/heads/main`, { sha: commit.sha, force: false });

  let tagResult: any = null;
  if (opts.tag) {
    const tagObj = await gh("POST", `${base}/git/tags`, {
      tag: opts.tag,
      message: opts.tagMessage || opts.tag,
      object: commit.sha,
      type: "commit",
    });
    try {
      await gh("POST", `${base}/git/refs`, { ref: `refs/tags/${opts.tag}`, sha: tagObj.sha });
      tagResult = tagObj.sha;
    } catch (e: any) {
      tagResult = `tag-ref failed: ${String(e?.message || e).slice(0, 100)}`;
    }
  }

  return { repo: opts.repo, parent, commit: commit.sha, files: uploaded, tag: tagResult };
}

async function main() {
  const results: any[] = [];

  // 独立仓库：源码 + 测试（无 zip、无 README）
  try {
    results.push(
      await pushRepo({
        repo: "hanshuang-load-tool",
        message:
          "feat: 5195 支持 Anthropic /v1/messages（thinking/text/tool_use 转换）与 OpenAI 非流式聚合；5190 流式加缓冲标记与计数；升版至 v1.2.8",
        files: [
          { local: `${SRC}/server.ts`, repoPath: "server.ts" },
          { local: `${SRC}/stream_engine.ts`, repoPath: "stream_engine.ts" },
          { local: `${SRC}/index.tsx`, repoPath: "index.tsx" },
          { local: `${SRC}/script.json`, repoPath: "script.json" },
          ...TEST_FILES.map((n) => ({ local: `${SRC}/tests/${n}`, repoPath: `tests/${n}` })),
        ],
        tag: "v1.2.8",
        tagMessage: "v1.2.8: 5195 双协议（OpenAI + Anthropic）与 5190 缓冲标记",
      })
    );
  } catch (e: any) {
    results.push({ repo: "hanshuang-load-tool", error: String(e?.message || e) });
  }

  // 合集仓库：源码 + README + dist zip
  try {
    results.push(
      await pushRepo({
        repo: "scripting-scripts",
        message: "feat: 寒霜注入工具 2 v1.2.8 - 5195 双协议（OpenAI 流式/非流式 + Anthropic /v1/messages）",
        files: [
          { local: `${PUSH}/寒霜注入工具 2/server.ts`, repoPath: "寒霜注入工具 2/server.ts" },
          { local: `${PUSH}/寒霜注入工具 2/stream_engine.ts`, repoPath: "寒霜注入工具 2/stream_engine.ts" },
          { local: `${PUSH}/寒霜注入工具 2/index.tsx`, repoPath: "寒霜注入工具 2/index.tsx" },
          { local: `${PUSH}/寒霜注入工具 2/script.json`, repoPath: "寒霜注入工具 2/script.json" },
          { local: `${PUSH}/README.md`, repoPath: "README.md" },
          { local: `${PUSH}/dist/寒霜注入工具 2.zip`, repoPath: "dist/寒霜注入工具 2.zip" },
          ...TEST_FILES.map((n) => ({
            local: `${PUSH}/寒霜注入工具 2/tests/${n}`,
            repoPath: `寒霜注入工具 2/tests/${n}`,
          })),
        ],
      })
    );
  } catch (e: any) {
    results.push({ repo: "scripting-scripts", error: String(e?.message || e) });
  }

  Script.exit({ results });
}

main();
